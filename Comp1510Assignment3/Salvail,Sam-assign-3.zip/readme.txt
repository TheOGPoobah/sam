Sam Salvail, A00927411, 1E, November 22, 2014

This assignment is 100% complete.

------------------------
Question one (Household) status:

COMPLETE

------------------------
Question two (Guess) status:

COMPLETE

------------------------
Question three (TestStudent and supporting classes) status:

COMPLETE

------------------------
Question four (TestCourse and supporting classes) status:

COMPLETE

------------------------
